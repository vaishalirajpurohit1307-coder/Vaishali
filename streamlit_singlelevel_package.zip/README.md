Attrition Streamlit App
=======================

Files included in this package (single-level, no folders):
- app.py        -> Main Streamlit application (launch with `streamlit run app.py`)
- utils.py      -> placeholder for helper functions (kept minimal)
- README.md     -> this file
- sample_run.sh -> hint for running locally

Notes for deployment to Streamlit Cloud:
1. Create a GitHub repo and push these files to the repo root.
2. In Streamlit Cloud, connect the GitHub repo and set `app.py` as the main file.
3. Add your `EA.csv` to the repo root (optional) or upload it in the app UI.
4. Use default packages in Streamlit Cloud. Typical required packages: streamlit, pandas, scikit-learn, plotly, seaborn, matplotlib, xlsxwriter.
   Streamlit Cloud provides a way to add packages without strict version pins; avoid pinning versions to minimize compatibility issues.
