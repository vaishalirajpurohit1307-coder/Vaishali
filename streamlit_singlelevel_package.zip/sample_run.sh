#!/bin/bash
# Run locally (if you have streamlit installed)
streamlit run app.py
