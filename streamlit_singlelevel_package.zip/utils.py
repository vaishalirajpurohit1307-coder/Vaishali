# (Left intentionally minimal.) All helpers are embedded in app.py for simplicity.
